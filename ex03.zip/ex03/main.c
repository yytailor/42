/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: amorfan <amorfan@student.42.fr>            +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2014/01/21 20:07:48 by amorfan           #+#    #+#             */
/*   Updated: 2014/01/21 21:55:06 by amorfan          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "alphlong.h"

int		main(int ac, char **av)
{
	int		i;
	t_index		*mega_root;

	i = 1;
	if (ac > 1)
	{
		while (av[i])
		{
			mega_root = ft_add_nood(&mega_root, ft_strlen(av[i]), av[i]);
			i++;
		}
		ft_print_infix(mega_root);
	}
	ft_putchar('\n');
	return (0);
}
