/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   tree.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: amorfan <amorfan@student.42.fr>            +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2014/01/21 20:29:36 by amorfan           #+#    #+#             */
/*   Updated: 2014/01/21 21:54:24 by amorfan          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "alphlong.h"

t_index	*ft_create_nood(int len, char *str)
{
	t_index		*tmp;
	if ((tmp = (t_index*)malloc(sizeof(t_index))) == NULL)
		return (NULL);
	tmp->len = len;
	tmp->left = NULL;
	tmp->right = NULL;
	tmp->racine = ft_add_elem(&tmp->racine, str);
	return (tmp);
}

t_index  *ft_add_nood(t_index **root, int len, char *str)
{
	if (*root == NULL)
		return (*root = ft_create_nood(len, str));
	else if (len == (*root)->len)
		(*root)->racine = ft_add_elem(&(*root)->racine, str);
	else if (len < (*root)->len)
		ft_add_nood(&(*root)->left, len, str);
	else if (len > (*root)->len)
		ft_add_nood(&(*root)->right, len, str);
	return (*root);
}

t_ascii	*ft_create_elem(char *s)
{
	t_ascii		*tmp;
	if ((tmp = (t_ascii *)malloc(sizeof(t_ascii))) == NULL)
		return (NULL);
	tmp->s = s;
	tmp->left = NULL;
	tmp->right = NULL;
	return (tmp);
}

t_ascii  *ft_add_elem(t_ascii **root, char *str)
{
	if (*root == NULL)
		return (*root = ft_create_elem(str));
	else if (ft_strcmp(str, (*root)->s) == 1)
		ft_add_elem(&(*root)->left, str);
	else if (ft_strcmp(str, (*root)->s) == 2 || ft_strcmp(str, (*root)->s) == 0)
		ft_add_elem(&(*root)->right, str);
	return (*root);
}

void	ft_print_infix(t_index *root)
{
	if (root->left != NULL)
		ft_print_infix(root->left);
	if (root->racine != NULL)
		ft_print_racine(root->racine);
	ft_putchar('\n');
	if (root->right != NULL)
		ft_print_infix(root->right);
	free(root);
}

void	ft_print_racine(t_ascii *racine)
{
	if (racine->left != NULL)
		ft_print_racine(racine->left);
	ft_putstr(racine->s);
	ft_putchar(' ');
	if (racine->right != NULL)
		ft_print_racine(racine->right);
	free(racine);
}
