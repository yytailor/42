/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   alphlong.h                                         :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: amorfan <amorfan@student.42.fr>            +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2014/01/21 20:02:03 by amorfan           #+#    #+#             */
/*   Updated: 2014/01/21 22:08:30 by amorfan          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef ALPHLONG_H
# define ALPHLONG_H
# include <unistd.h>
# include <stdlib.h>

typedef struct		s_ascii
{
	char			*s;
	struct s_ascii	*left;
	struct s_ascii	*right;
}					t_ascii;

typedef struct		s_index
{
	int				len;
	struct s_index	*left;
	struct s_index	*right;
	t_ascii			*racine ;
}					t_index;

void		ft_putchar(char c);
void		ft_putstr(char *s);
int			ft_strlen(char *s);
int			ft_maj(char c);
int			ft_strcmp(char *s1, char *s2);
int			ft_charcmp(char c, char d);
t_index		*ft_create(int len, char *str);
t_index		*ft_add_nood(t_index **root, int len, char *str);
t_ascii		*ft_create_elem(char *s);
t_ascii		*ft_add_elem(t_ascii **root, char *str);
void		ft_print_infix(t_index *root);
void		ft_print_racine(t_ascii *racine);

#endif
