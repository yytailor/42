/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   libft.c                                            :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: amorfan <amorfan@student.42.fr>            +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2014/01/21 20:08:59 by amorfan           #+#    #+#             */
/*   Updated: 2014/01/21 22:10:29 by amorfan          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "alphlong.h"

void		ft_putchar(char c)
{
	write(1, &c, 1);
}

int			ft_strlen(char *s)
{
	int i;
	i = 0;

	while (s[i] != '\0')
		i++;
	return (i);
}

void		ft_putstr(char *s)
{
	int i;
	i = 0;
	while (s[i] != '\0')
	{
		ft_putchar(s[i]);
		i++;
	}
}


int         ft_strcmp(char *s1, char *s2)
{
    int     i;
	int		j;

	j = 0;
    while ((s1[j] != '\0' || s2[j] != '\0') && (i = ft_charcmp(s1[j], s2[j]) == 0))
		j++;
    return (i);
}

int         ft_charcmp(char c, char d)
{
    int     ret;

    if (ft_maj(c) == 1)
        c = c + 32;
    if (ft_maj(d) == 1)
        d = d + 32;
    if (c == d)
        return (0);
    ret = (c < d)? 1 : 2;
    return (ret);
}

int         ft_maj(char c)
{
    if (c >= 65 && c <= 90)
        return (1);
    return (0);
}

/*int			ft_strcmp(char *s1, char *s2)
{
	int		i;

	i = 0;
	while (s1[i])
	{
		if (s1[i] >= 'A' && s1[i] <= 'Z')
			s1[i] = s1[i] + 32;
		i++;
	}
	i = 0;
	while (s2[i])
	{
		if (s2[i] >= 'A' && s2[i] <= 'Z')
			s2[i] = s2[i] + 32;
		i++;
	}
	i = 0;
	while ((s1[i] == s2[i]) && s1[i] != '\0' && s2[i] != '\0')
		i++;
	if (s1[i] == '\0')
		return (0);
	return ((s1[i] < s2[i])? 1 : 2);
}
*/
